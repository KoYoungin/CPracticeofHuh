#include<stdio.h>

int main(void)
{
	printf("number\tsquare\tcube \n");
	int num, squ, cub;
	num = 0;

	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num=num+1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);
	num = num + 1;
	printf("%d\t%d\t%d\n", num, num*num, num*num*num);

	return 0;


	

	

}